/**
 * Exercício 05 – Função de multiplicação
 * Criar uma função que receba dois números e retorne a multiplicação.
 */

function multiplicar(a: number, b: number): number {
  return a * b;
}

console.log(`Resultado: ${multiplicar(6, 7)}`);
