/**
 * Exercício 01 – Função de saudação
 * Criar uma função que exibe "Olá, Mundo!".
 */

function saudacao(): void {
  console.log("Olá, Mundo!");
}

// Chamando a função
saudacao();