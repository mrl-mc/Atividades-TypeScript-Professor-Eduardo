/**
 * Exercício 04 – Função de subtração
 * Criar uma função que receba dois números e retorne a subtração.
 */
function subtrair(a, b) {
    return a - b;
}
console.log("Resultado: ".concat(subtrair(20, 8)));
