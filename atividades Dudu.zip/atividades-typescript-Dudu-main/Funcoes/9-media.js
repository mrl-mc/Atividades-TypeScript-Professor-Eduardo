/**
 * Exercício 09 – Função média de notas
 * Criar uma função que receba 3 notas e retorne a média.
 */
function media(n1, n2, n3) {
    return (n1 + n2 + n3) / 3;
}
console.log("M\u00E9dia = ".concat(media(7, 8, 6).toFixed(2)));
