/**
 * Exercício 02 – Função com parâmetro
 * Criar uma função que receba um nome e exiba "Olá, <nome>".
 */

function dizerOla(nome: string): void {
  console.log(`Olá, ${nome}!`);
}

dizerOla("Eduardo");
dizerOla("Pietro");
