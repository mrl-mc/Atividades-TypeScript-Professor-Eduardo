/**
 * Exercício 03 – Função com retorno
 * Criar uma função que receba dois números e retorne a soma.
 */
function somar(a, b) {
    return a + b;
}
console.log("Resultado: ".concat(somar(10, 5)));
