/**
 * Exercício 13 – Conversão Celsius → Fahrenheit
 * F = C * 1.8 + 32
 */
function celsiusParaFahrenheit(c) {
    return c * 1.8 + 32;
}
console.log("25\u00B0C = ".concat(celsiusParaFahrenheit(25), "\u00B0F"));
