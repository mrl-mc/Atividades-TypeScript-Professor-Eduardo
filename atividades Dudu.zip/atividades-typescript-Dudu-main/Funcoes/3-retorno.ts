/**
 * Exercício 03 – Função com retorno
 * Criar uma função que receba dois números e retorne a soma.
 */

function somar(a: number, b: number): number {
  return a + b;
}

console.log(`Resultado: ${somar(10, 5)}`);