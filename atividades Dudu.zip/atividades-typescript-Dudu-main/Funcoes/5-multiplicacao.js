/**
 * Exercício 05 – Função de multiplicação
 * Criar uma função que receba dois números e retorne a multiplicação.
 */
function multiplicar(a, b) {
    return a * b;
}
console.log("Resultado: ".concat(multiplicar(6, 7)));
