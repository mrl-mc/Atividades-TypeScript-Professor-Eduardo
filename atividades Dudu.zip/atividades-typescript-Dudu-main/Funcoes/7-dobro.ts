/**
 * Exercício 07 – Função dobro
 * Criar uma função que receba um número e retorne o dobro dele.
 */

function dobro(n: number): number {
  return n * 2;
}

console.log(`Dobro de 12 = ${dobro(12)}`);

