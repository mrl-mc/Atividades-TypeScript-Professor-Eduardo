/**
 * Exercício 02 – Função com parâmetro
 * Criar uma função que receba um nome e exiba "Olá, <nome>".
 */
function dizerOla(nome) {
    console.log("Ol\u00E1, ".concat(nome, "!"));
}
dizerOla("Eduardo");
dizerOla("Pietro");
