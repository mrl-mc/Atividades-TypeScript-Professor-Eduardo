// Exemplo 3: Operadores de Atribuição
var x = 20;
x += 10; // Equivalente a x = x + 10
console.log("Atribuição de Soma:", x);
x -= 5; // Equivalente a x = x - 5
console.log("Atribuição de Subtração:", x);
x *= 2; // Equivalente a x = x * 2
console.log("Atribuição de Multiplicação:", x);
x /= 4; // Equivalente a x = x / 4
console.log("Atribuição de Divisão:", x);
x %= 3; // Equivalente a x = x % 3
console.log("Atribuição de Módulo:", x);
