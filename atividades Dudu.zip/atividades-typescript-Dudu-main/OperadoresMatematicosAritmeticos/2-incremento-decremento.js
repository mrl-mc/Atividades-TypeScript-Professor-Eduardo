// Exemplo 2: Operadores de Incremento e Decremento
var contador = 0;
contador++; // Incremento (equivalente a contador = contador + 1)
console.log("Incremento:", contador);
contador--; // Decremento (equivalente a contador = contador - 1)
console.log("Decremento:", contador);
