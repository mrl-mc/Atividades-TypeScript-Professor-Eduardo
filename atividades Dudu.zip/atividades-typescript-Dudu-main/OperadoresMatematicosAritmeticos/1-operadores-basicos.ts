// Exemplo 1: Operadores Aritméticos Básicos
let a: number = 10;
let b: number = 5;

console.log("Soma:", a + b);        // Adição
console.log("Subtração:", a - b);   // Subtração
console.log("Multiplicação:", a * b); // Multiplicação
console.log("Divisão:", a / b);     // Divisão
console.log("Módulo:", a % b);     // Resto da divisão
console.log("Exponenciação:", a ** b); // Potenciação
