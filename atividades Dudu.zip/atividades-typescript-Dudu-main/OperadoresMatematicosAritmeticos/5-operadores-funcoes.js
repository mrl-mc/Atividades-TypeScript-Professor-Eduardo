// Exemplo 5: Operadores Matemáticos em Funções
function calcularQuadrado(num) {
    return Math.pow(num, 2);
}
console.log("Quadrado de 4:", calcularQuadrado(4));
