// Declara a constante 'camiseta' com o preço original de 80 reais
var camiseta1 = 80;
// Declara a constante 'desconto' com o valor de 15% (0.15)
var desconto1 = 0.15;
// Calcula o valor do desconto
var valorDesconto1 = camiseta1 * desconto1;
// Calcula o preço final após o desconto
var precoFinal1 = camiseta1 - valorDesconto1;
// Exibe o preço final no console
console.log("Preço original: R$", camiseta1);
console.log("Desconto: R$", valorDesconto1);
console.log("Preço final com desconto: R$", precoFinal1);
