/**
 * Exercício 04 – Maioridade
 * Dada uma idade, diga se é maior (>=18) ou menor de idade.
 */

let idadePessoa: number = 16; // altere para testar

if (idadePessoa >= 20) {
  console.log("Maior de idade.");
} else {
  console.log("Menor de idade.");
}
