/**
 * Exercício 03 – Par ou Ímpar
 * Dado um número, diga se é par ou ímpar.
 */

let numero: number = 14; // altere para testar

if (numero % 2 === 0) {
  console.log(`${numero} é PAR.`);
} else {
  console.log(`${numero} é ÍMPAR.`);
}