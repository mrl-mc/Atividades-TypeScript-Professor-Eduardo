/**
 * Exercício 03 – Par ou Ímpar
 * Dado um número, diga se é par ou ímpar.
 */
var numero = 14; // altere para testar
if (numero % 2 === 0) {
    console.log("".concat(numero, " \u00E9 PAR."));
}
else {
    console.log("".concat(numero, " \u00E9 \u00CDMPAR."));
}
