/**
 * Exercício 02 – Variáveis simples
 * Declare nome, idade e cidade e imprima uma frase.
 */
var nome = "Giovana";
var idade = 19;
var cidade = "Campo Limpo Paulista";
console.log("Meu nome \u00E9 ".concat(nome, ", tenho ").concat(idade, " anos e moro em ").concat(cidade, "."));
