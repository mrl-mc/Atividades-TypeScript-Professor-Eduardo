/**
 * Exercício 02 – Variáveis simples
 * Declare nome, idade e cidade e imprima uma frase.
 */

let nome: string = "Giovana";
let idade: number = 19;
let cidade: string = "Campo Limpo Paulista";

console.log(`Meu nome é ${nome}, tenho ${idade} anos e moro em ${cidade}.`);
