/**
 * Exercício 04 – Maioridade
 * Dada uma idade, diga se é maior (>=18) ou menor de idade.
 */
var idadePessoa = 20; // altere para testar
if (idadePessoa >= 18) {
    console.log("Maior de idade.");
}
else {
    console.log("Menor de idade.");
}
