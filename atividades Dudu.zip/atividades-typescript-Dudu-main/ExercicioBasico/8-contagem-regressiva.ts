/**
 * Exercício 08 – Contagem Regressiva
 * Conte de 10 até 1 e ao final exiba "Lançar foguete!".
 */

for (let i = 10; i >= 1; i--) {
  console.log(i);
}

console.log("Lançar foguete!");