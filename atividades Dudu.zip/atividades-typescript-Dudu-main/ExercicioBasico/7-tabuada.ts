/**
 * Exercício 07 – Tabuada
 * Mostre a tabuada de 1 a 10 de um número.
 */

let base: number = 7; // altere para testar

for (let i = 1; i <= 10; i++) {
  console.log(`${base} x ${i} = ${base * i}`);
}
