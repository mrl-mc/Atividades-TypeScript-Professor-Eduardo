/**
 * Exercício 07 – Tabuada
 * Mostre a tabuada de 1 a 10 de um número.
 */
var base = 7; // altere para testar
for (var i = 1; i <= 10; i++) {
    console.log("".concat(base, " x ").concat(i, " = ").concat(base * i));
}
