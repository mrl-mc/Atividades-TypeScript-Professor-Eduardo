/**
 * Exercício 01 – Olá Mundo
 * Objetivo: imprimir uma mensagem no console.
 */

console.log("Olá, TypeScript!");
