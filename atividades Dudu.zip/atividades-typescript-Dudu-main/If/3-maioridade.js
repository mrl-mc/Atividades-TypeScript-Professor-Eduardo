/**
 * Exercício 03 – Maioridade
 * Verifique se a pessoa é maior ou menor de idade.
 */
var idade = 17;
if (idade >= 18) {
    console.log("Maior de idade.");
}
else {
    console.log("Menor de idade.");
}
