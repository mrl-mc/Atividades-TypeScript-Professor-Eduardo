/**
 * Exercício 04 – Nota de aprovação
 * Verifique se o aluno foi aprovado (nota >= 6).
 */
var nota = 5;
if (nota >= 6) {
    console.log("Aluno aprovado.");
}
else {
    console.log("Aluno reprovado.");
}
