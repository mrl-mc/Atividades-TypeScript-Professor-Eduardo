/**
 * Exercício 02 – Par ou Ímpar
 * Verifique se um número é par ou ímpar.
 */
var valor = 12;
if (valor % 2 === 0) {
    console.log("".concat(valor, " \u00E9 par."));
}
else {
    console.log("".concat(valor, " \u00E9 \u00EDmpar."));
}
