/**
 * Exercício 12 – Faixa de notas
 * A (>=90), B (>=80), C (>=70), D (>=60), F (<60).
 */

let notaAluno: number = 82;

if (notaAluno >= 90) {
  console.log("Conceito A");
} else if (notaAluno >= 80) {
  console.log("Conceito B");
} else if (notaAluno >= 70) {
  console.log("Conceito C");
} else if (notaAluno >= 60) {
  console.log("Conceito D");
} else {
  console.log("Conceito F");
}
