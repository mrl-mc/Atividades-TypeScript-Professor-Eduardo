/**
 * Exercício 01 – Positivo ou Negativo
 * Verifique se um número é positivo ou negativo.
 */
var numero = -5;
if (numero >= 0) {
    console.log("".concat(numero, " \u00E9 positivo."));
}
else {
    console.log("".concat(numero, " \u00E9 negativo."));
}
