/**
 * Exercício 02 – Par ou Ímpar
 * Verifique se um número é par ou ímpar.
 */

let valor: number = 12;

if (valor % 2 === 0) {
  console.log(`${valor} é par.`);
} else {
  console.log(`${valor} é ímpar.`);
}
