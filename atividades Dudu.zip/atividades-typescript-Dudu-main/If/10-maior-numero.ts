/**
 * Exercício 10 – Maior número
 * Mostre qual número é maior entre dois valores.
 */

let a: number = 25;
let b: number = 42;

if (a > b) {
  console.log(`${a} é maior que ${b}.`);
} else if (b > a) {
  console.log(`${b} é maior que ${a}.`);
} else {
  console.log("Os números são iguais.");
}
