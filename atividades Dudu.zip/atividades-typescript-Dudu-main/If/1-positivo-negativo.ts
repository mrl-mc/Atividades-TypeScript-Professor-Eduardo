/**
 * Exercício 01 – Positivo ou Negativo
 * Verifique se um número é positivo ou negativo.
 */

let numero: number = -5;

if (numero >= 0) {
  console.log(`${numero} é positivo.`);
} else {
  console.log(`${numero} é negativo.`);
}