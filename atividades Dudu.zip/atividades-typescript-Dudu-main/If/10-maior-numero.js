/**
 * Exercício 10 – Maior número
 * Mostre qual número é maior entre dois valores.
 */
var a = 25;
var b = 42;
if (a > b) {
    console.log("".concat(a, " \u00E9 maior que ").concat(b, "."));
}
else if (b > a) {
    console.log("".concat(b, " \u00E9 maior que ").concat(a, "."));
}
else {
    console.log("Os números são iguais.");
}
