/**
 * Exercício 01 – Contador simples
 * Conte de 1 a 10 usando while.
 */
var i = 1;
while (i <= 10) {
    console.log(i);
    i++; // incrementa para não travar o loop
}
